function porto(){
    document.getElementById("portcolor").style.backgroundColor = "#282c33"
    document.getElementById("portcolor").style.transition = "0.5s"
}
function porto1(){
    document.getElementById("portcolor").style.backgroundColor = "#c778dd"
    document.getElementById("portcolor").style.transition = "0.5s"
}

function kkkx(){
    document.getElementById("kkkxx").style.color = "#c778dd"
    document.getElementById("kkkxx").style.transition = "0.1s"
}
function kkkx1(){
    document.getElementById("kkkxx").style.color = "white"
    document.getElementById("kkkxx").style.transition = "0.1s"
}

